<?php

namespace App\Command;

use App\Entity\Departement;
use App\Entity\StatistiquesDepartement;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

#[AsCommand(
    name: 'app:import:stats-departement',
    description: 'Import des statistiques département depuis un CSV'
)]
class ImportStatistiquesDepartementCommand extends Command
{
    public function __construct(private EntityManagerInterface $em)
    {
        parent::__construct();
    }

    protected function configure(): void
    {
        $this->addArgument('file', InputArgument::REQUIRED, 'Chemin du fichier CSV');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $filePath = $input->getArgument('file');
        if (!file_exists($filePath)) {
            $output->writeln('<error>Fichier introuvable</error>');
            return Command::FAILURE;
        }

        // Détection automatique du séparateur (virgule ou point-virgule)
        $content = file_get_contents($filePath);
        $separator = (str_contains(str_getcsv($content, "\n")[0], ';')) ? ';' : ',';

        $handle = fopen($filePath, 'r');
        
        // Lecture et nettoyage complet des en-têtes
        $rawHeader = fgetcsv($handle, 0, $separator);
        $header = array_map(function($h) {
            // Enlève les guillemets, les espaces bizarres et les caractères spéciaux
            $h = trim($h, " \t\n\r\0\x0B\"");
            return preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $h);
        }, $rawHeader);
        
        $i = 0;
        $batchSize = 20;

        while (($row = fgetcsv($handle, 0, $separator)) !== false) {
            if (count($header) !== count($row)) continue;

            $data = array_combine($header, $row);
            
            // On cherche le code département dans les différentes colonnes possibles
            $rawCode = $data['code_departement'] ?? $data['code_dept'] ?? $data['code'] ?? '';
            $code = $this->formatCodeDepartement($rawCode);
            
            $departement = $this->em->getRepository(Departement::class)->find($code);

            if (!$departement) {
                continue; 
            }

            $stat = new StatistiquesDepartement();
            $stat->setDepartement($departement);
            
            // Récupération de l'année
            $annee = $data['année_publication'] ?? $data['annee_publication'] ?? 2021;
            $stat->setAnneePublication((int)$annee);
            
            // Nettoyage et insertion des chiffres
            // Note : utilisez les noms EXACTS de vos colonnes CSV ici
            $stat->setNombreHabitants($this->int($data["Nombre d'habitants"] ?? 0));
            $stat->setDensitePopulation($this->decimal($data["Densité de population au km²"] ?? 0));
            $stat->setTauxChomageT4($this->decimal($data["Taux de chômage au T4 (en %)"] ?? 0));

            $this->em->persist($stat);

            if (($i % $batchSize) === 0) {
                $this->em->flush();
            }
            $i++;
        }

        $this->em->flush();
        fclose($handle);
        $output->writeln("<info>Succès ! Import terminé : $i lignes traitées.</info>");

        return Command::SUCCESS;
    }

    private function decimal($value): ?string {
        if ($value === null || $value === '') return null;
        $value = str_replace(',', '.', $value);
        $value = preg_replace('/[^0-9.]/', '', $value);
        return number_format((float)$value, 2, '.', '');
    }

    private function int($value): ?int {
        if ($value === null || $value === '') return null;
        $value = preg_replace('/[^0-9]/', '', $value);
        return (int)$value;
    }

    private function formatCodeDepartement(string $code): string {
        $code = strtoupper(trim($code, " \""));
        if ($code === '2A' || $code === '2B') return $code;
        if (strlen($code) === 3) return $code;
        return str_pad($code, 2, '0', STR_PAD_LEFT);
    }
}